// Self fast-learning logic file

// Collapsible conversation sidebar component

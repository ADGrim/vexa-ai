// Onboarding modal with welcome instructions

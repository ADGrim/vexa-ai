// AnimatedBlackHole component code here

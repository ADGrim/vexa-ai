// Sample app layout importing all components

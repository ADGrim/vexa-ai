// Generate image function for OpenAI or Stability API

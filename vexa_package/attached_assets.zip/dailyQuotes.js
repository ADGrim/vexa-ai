// Daily inspirational quotes list

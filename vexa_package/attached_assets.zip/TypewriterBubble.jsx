// TypewriterBubble component code here

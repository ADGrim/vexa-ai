```typescript
export { useVoiceHandler } from './VoiceHandler';
export { WaveAnimation } from './WaveAnimation';
export { VoiceButton } from './VoiceButton';
```

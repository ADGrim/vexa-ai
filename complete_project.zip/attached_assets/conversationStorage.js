// Save/load conversations to localStorage

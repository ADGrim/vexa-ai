// Settings modal with toggles for Nova voice and theme

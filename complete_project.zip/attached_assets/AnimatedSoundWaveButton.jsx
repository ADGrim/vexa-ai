// AnimatedSoundWaveButton component code here

// ChatInputBar component code here

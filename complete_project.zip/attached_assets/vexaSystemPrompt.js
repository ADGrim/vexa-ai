// System prompt with expert conversational persona

// Guidelines to block unsafe/destructive topics

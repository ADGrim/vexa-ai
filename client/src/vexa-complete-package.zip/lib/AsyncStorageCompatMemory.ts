/**
 * AsyncStorage-compatible implementation of ConversationMemory for web
 * This provides the same API as the AsyncStorageMemory.ts in expo-components
 * but uses localStorage for web applications
 */

import { vexaSystemPrompt } from './vexaSystemPrompt';
import { ConversationMessage, ConversationMemory } from './conversationMemory';

/**
 * Save a key-value pair to persistent storage
 * @param key The storage key
 * @param value The string value to store
 */
export const saveMemory = async (key: string, value: string): Promise<void> => {
  try {
    localStorage.setItem(key, value);
  } catch (err) {
    console.error('Memory save failed', err);
  }
};

/**
 * Retrieve a value from persistent storage
 * @param key The storage key to retrieve
 * @returns The stored value, or null if not found
 */
export const getMemory = async (key: string): Promise<string | null> => {
  try {
    return localStorage.getItem(key);
  } catch (err) {
    console.error('Memory retrieval failed', err);
    return null;
  }
};

/**
 * Load all key-value pairs with a specific prefix
 * @param prefix The prefix to filter keys by (optional)
 * @returns A Record object with all matching key-value pairs
 */
export const loadAllMemory = async (prefix?: string): Promise<Record<string, string>> => {
  try {
    const result: Record<string, string> = {};
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (!prefix || key.startsWith(prefix))) {
        const value = localStorage.getItem(key);
        if (value !== null) {
          result[key] = value;
        }
      }
    }
    
    return result;
  } catch (err) {
    console.error('Loading all memory failed', err);
    return {};
  }
};

/**
 * Remove a specific value from storage
 * @param key The key to remove
 */
export const removeMemory = async (key: string): Promise<void> => {
  try {
    localStorage.removeItem(key);
  } catch (err) {
    console.error('Memory removal failed', err);
  }
};

/**
 * Clear all stored values
 * @param prefix Optional prefix to only clear keys that start with this prefix
 */
export const clearMemory = async (prefix?: string): Promise<void> => {
  try {
    if (prefix) {
      const keysToRemove: string[] = [];
      
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(prefix)) {
          keysToRemove.push(key);
        }
      }
      
      keysToRemove.forEach(key => localStorage.removeItem(key));
    } else {
      localStorage.clear();
    }
  } catch (err) {
    console.error('Memory clear failed', err);
  }
};

/**
 * Utility functions specific to conversation memory
 */

const MEMORY_KEY = 'vexa_conversation_memory';
const MAX_MEMORY_LENGTH = 100;

/**
 * Add a message to the conversation memory
 */
export const addToConversationMemory = async (
  role: ConversationMessage['role'],
  content: string,
  maxMemoryLength: number = MAX_MEMORY_LENGTH
): Promise<ConversationMemory> => {
  try {
    const memoryStr = await getMemory(MEMORY_KEY);
    let memory: ConversationMemory = [];
    
    if (memoryStr) {
      memory = JSON.parse(memoryStr);
    } else {
      memory = [{ role: 'system', content: vexaSystemPrompt }];
    }
    
    const updatedMemory = [...memory, { role, content }];
    
    if (updatedMemory.length > maxMemoryLength) {
      updatedMemory.splice(1, updatedMemory.length - maxMemoryLength - 1);
    }
    
    await saveMemory(MEMORY_KEY, JSON.stringify(updatedMemory));
    return updatedMemory;
  } catch (error) {
    console.error('Failed to add to conversation memory:', error);
    return [{ role: 'system', content: vexaSystemPrompt }];
  }
};

/**
 * Load the conversation memory
 */
export const loadConversationMemory = async (): Promise<ConversationMemory> => {
  try {
    const stored = await getMemory(MEMORY_KEY);
    if (!stored) {
      return [{ role: 'system', content: vexaSystemPrompt }];
    }
    return JSON.parse(stored);
  } catch (error) {
    console.error('Failed to load conversation memory:', error);
    return [{ role: 'system', content: vexaSystemPrompt }];
  }
};

/**
 * Clear the conversation memory
 */
export const clearConversationMemory = async (): Promise<void> => {
  try {
    await removeMemory(MEMORY_KEY);
  } catch (error) {
    console.error('Failed to clear conversation memory:', error);
  }
};
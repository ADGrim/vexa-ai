/**
 * IMPORTANT: This file is for React Native use only
 * It requires '@react-native-async-storage/async-storage' package to be installed
 * Install with: npm install @react-native-async-storage/async-storage
 * 
 * This provides an alternative storage implementation using AsyncStorage
 * instead of expo-file-system, which may be preferable in certain React Native setups.
 */

// @ts-ignore - Ignoring import error since this will only be used in React Native environment
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Save a key-value pair to persistent storage
 * @param key The storage key
 * @param value The string value to store
 */
export const saveMemory = async (key: string, value: string) => {
  try {
    await AsyncStorage.setItem(key, value);
  } catch (err) {
    console.error('Memory save failed', err);
  }
};

/**
 * Retrieve a value from persistent storage
 * @param key The storage key to retrieve
 * @returns The stored value, or null if not found
 */
export const getMemory = async (key: string): Promise<string | null> => {
  try {
    return await AsyncStorage.getItem(key);
  } catch (err) {
    console.error('Memory retrieval failed', err);
    return null;
  }
};

/**
 * Load all key-value pairs with a specific prefix
 * @param prefix The prefix to filter keys by (optional)
 * @returns A Record object with all matching key-value pairs
 */
export const loadAllMemory = async (prefix?: string): Promise<Record<string, string>> => {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const filteredKeys = prefix ? keys.filter(key => key.startsWith(prefix)) : keys;
    const pairs = await AsyncStorage.multiGet(filteredKeys);
    
    return pairs.reduce((result, [key, value]) => {
      if (value !== null) {
        result[key] = value;
      }
      return result;
    }, {} as Record<string, string>);
  } catch (err) {
    console.error('Loading all memory failed', err);
    return {};
  }
};

/**
 * Remove a specific value from storage
 * @param key The key to remove
 */
export const removeMemory = async (key: string) => {
  try {
    await AsyncStorage.removeItem(key);
  } catch (err) {
    console.error('Memory removal failed', err);
  }
};

/**
 * Clear all stored values
 * @param prefix Optional prefix to only clear keys that start with this prefix
 */
export const clearMemory = async (prefix?: string) => {
  try {
    if (prefix) {
      const keys = await AsyncStorage.getAllKeys();
      const keysToRemove = keys.filter(key => key.startsWith(prefix));
      await AsyncStorage.multiRemove(keysToRemove);
    } else {
      await AsyncStorage.clear();
    }
  } catch (err) {
    console.error('Memory clear failed', err);
  }
};